// object methods/functions // line 0
testModule = (function() {     // line 1
    return {         // line 2
                     // line 3

        }           // line 4
                     // line 5
})();                // line 6
